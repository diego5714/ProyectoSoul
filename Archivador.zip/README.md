# ProyectoSoul
Github público con el desarrollo del videojuego ProyectoSouls para el taller CC5408.

Somos estudiantes de la Facultad de ciencias físicas y matemáticas de la universidad de Chile.
Pertenecemos al grupo "Disobedient Cat", de la seccion 1 del taller de diseño y desarrollo de videojuegos (CC5408)
